<?php get_header(); ?>
<h1>Hello from index.php</h1>
<?php get_footer(); ?>
