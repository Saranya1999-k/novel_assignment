<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?></title>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header class="site-header">
  <div class="container">
    <!-- Logo -->
    <div class="logo">
      <a href="<?php echo home_url(); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/images/logo.webp" loading="lazy" alt="Novel Office Logo">
      </a>
    </div>

    <!-- Static Navigation Links -->
    <nav class="main-nav">
      <ul class="nav-menu">
        <li><a href="/">Home</a></li>
        <li><a href="#solutions">Solutions</a></li>

        <!-- ✅ Locations Dropdown -->
        <li class="dropdown">
          <a href="#locations">Locations <span class="dropdown-icon">▼</span></a>
          <ul class="submenu">
            <li><a href="#marathahalli">MARATHAHALLI</a></li>
            <li><a href="#mgroad">MG ROAD</a></li>
            <li><a href="#whitefield-now">WHITEFIELD(NOW)</a></li>
            <li><a href="#whitefield-btp">WHITEFIELD(BTP)</a></li>
            <li><a href="queensroad">QUEENS ROAD</a></li>
            <li><a href="#koramangala">KORAMANGALA</a></li>
            <li><a href="#hsrextension">HSR EXTENSION</a></li>
            <li><a href="#alllocations">ALL LOCATIONS</a></li>
          </ul>
        </li>

        <li><a href="#investments">Investments</a></li>
        <li><a href="#contact">Contact Us</a></li>
        <li><a href="#more">More</a></li>
      </ul>
    </nav>
  </div>
</header>
