<?php get_header(); ?>

<section class="hero-banner">
  <img src="<?php echo get_template_directory_uri(); ?>/images/slide1.png" alt="Office Banner" loading="lazy">
</section>

<?php get_footer(); ?>


<section class="testimonials">
  
  <?php
    $testimonials = new WP_Query(array(
      'post_type' => 'testimonial',
      'posts_per_page' => 3
    ));
    if ($testimonials->have_posts()):
      while ($testimonials->have_posts()): $testimonials->the_post(); ?>
        <div class="testimonial">
          <h3><?php the_title(); ?></h3>
          <div><?php the_content(); ?></div>
        </div>
      <?php endwhile;
      wp_reset_postdata();
    endif;
  ?>
</section>
