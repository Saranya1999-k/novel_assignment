<?php
function mycustomtheme_enqueue_styles() {
    wp_enqueue_style('mycustomtheme-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'mycustomtheme_enqueue_styles');

function create_testimonial_cpt() {
    $labels = array(
        'name' => __('Testimonials'),
        'singular_name' => __('Testimonial'),
        'add_new' => __('Add New Testimonial'),
        'add_new_item' => __('Add New Testimonial'),
        'edit_item' => __('Edit Testimonial'),
        'new_item' => __('New Testimonial'),
        'view_item' => __('View Testimonial'),
        'search_items' => __('Search Testimonials'),
        'not_found' => __('No Testimonials Found'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => false,
        'rewrite' => array('slug' => 'testimonials'),
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
    );

    register_post_type('testimonial', $args);
}
add_action('init', 'create_testimonial_cpt');
